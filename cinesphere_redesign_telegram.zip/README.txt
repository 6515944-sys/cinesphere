CINESPHERE Movie Website

1. index.html ကို Android Chrome ဖြင့်ဖွင့်ပြီး စမ်းသပ်ပါ။
2. Code editor ဖြင့် index.html ကိုဖွင့်ပါ။
3. CHANNEL_URL ကို သင့် Telegram Channel URL ဖြင့် ပြောင်းပါ။
4. movies စာရင်းတွင် title, year, category, rating, summary, posterUrl, telegram ကို ပြောင်းပါ။
5. GitHub Pages တွင် index.html ကို upload လုပ်ပြီး အခမဲ့ host လုပ်နိုင်ပါသည်။

မှတ်ချက်: လက်ရှိ poster များသည် emoji/gradient နမူနာများသာ ဖြစ်ပါသည်။
Poster အစစ်များကို အသုံးပြုခွင့်ရှိသော ပုံ URL များဖြင့် အစားထိုးပါ။

Telegram channel connected: https://t.me/CinesphereMM
Movie-specific Telegram post links must be added separately in movies[].telegram.
