CINESPHERE BOOST - Android starter project

ပါဝင်သောအရာများ
- Neon အနက်/ခရမ်း UI
- Genre အလိုက် Hashtag generator
- မြန်မာ Caption starter generator
- View / follower အရေအတွက်ကို ကိုယ်တိုင်မှတ်တမ်းတင်ရန် tracker
- Content growth tips

အရေးကြီးချက်
- ဒီ starter app က TikTok view/follower ကို အလိုအလျောက်တိုးမပေးပါ။
- Fake engagement, bot, auto-follow စနစ် မပါဝင်ပါ။
- TikTok account password ကို မတောင်းပါ။
- Tracker က ယခု starter version တွင် app ဖွင့်ထားစဉ်အတွင်းသာ မှတ်ထားပါသည်။
- TikTok API ချိတ်ဆက်မှု မပါဝင်သေးပါ။ Official API access နှင့် ခွင့်ပြုချက်များ လိုအပ်နိုင်သည်။

APK Build လုပ်ရန်
1. Android Studio ကို ကွန်ပျူတာတွင် install လုပ်ပါ။
2. ဒီ ZIP ကို extract လုပ်ပါ။
3. Android Studio > Open > CINESPHERE_BOOST folder ကိုရွေးပါ။
4. Gradle sync ပြီးသည်အထိ စောင့်ပါ။
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
6. Build အောင်မြင်လျှင် app/build/outputs/apk/debug/app-debug.apk တွင် ရှိပါမည်။

လိုအပ်ချက်
- Android Studio (ဤ project တွင် AGP 8.7.3 / Kotlin 2.0.21)
- JDK 17
