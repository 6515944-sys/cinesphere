package com.cinesphere.boost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF171226)
private val Purple = Color(0xFFB45CFF)
private val Cyan = Color(0xFF5CE1E6)
private val White = Color(0xFFF6F0FF)
private val Muted = Color(0xFFB8ADC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BoostApp() }
    }
}

@Composable
fun BoostApp() {
    var page by remember { mutableStateOf("Home") }
    var movie by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("Action") }
    var caption by remember { mutableStateOf("") }
    var views by remember { mutableStateOf("") }
    var followers by remember { mutableStateOf("") }
    var savedViews by remember { mutableStateOf(0) }
    var savedFollowers by remember { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple, secondary = Cyan,
        onBackground = White, onSurface = White
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {
                Text("CINESPHERE", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("BOOST", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("Create smarter. Grow organically.", color = Muted, fontSize = 12.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Home", "Hashtags", "Scripts", "Tracker", "Tips").forEach {
                    NavigationChip(it, page == it) { page = it }
                }
            }
            Spacer(Modifier.height(12.dp))
            when (page) {
                "Home" -> HomePage { page = it }
                "Hashtags" -> HashtagPage(genre, { genre = it }, { clipboard.setText(AnnotatedString(it)) })
                "Scripts" -> ScriptPage(movie, { movie = it }, caption, { caption = it }, { clipboard.setText(AnnotatedString(it)) })
                "Tracker" -> TrackerPage(views, { views = it }, followers, { followers = it },
                    savedViews, savedFollowers, {
                        savedViews = views.toIntOrNull() ?: savedViews
                        savedFollowers = followers.toIntOrNull() ?: savedFollowers
                    })
                else -> TipsPage()
            }
            Spacer(Modifier.weight(1f))
            Text("Unofficial creator toolkit • No fake engagement", color = Muted, fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(12.dp))
        }
    }
}

@Composable
fun NavigationChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) Purple.copy(alpha = .22f) else Panel,
        shape = MaterialTheme.shapes.medium, modifier = Modifier.weight(1f).clickable { onClick() }) {
        Text(label, color = if (selected) Cyan else Muted, fontSize = 10.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp).wrapContentWidth(Alignment.CenterHorizontally))
    }
}

@Composable
fun PageTitle(title: String, subtitle: String) {
    Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(14.dp))
}

@Composable
fun HomePage(go: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        PageTitle("Creator dashboard", "Tools to plan and improve your movie content")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("CONTENT", "Ideas", "Plan your next post", Modifier.weight(1f))
            StatCard("GROWTH", "Organic", "Build real viewers", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        listOf(
            Triple("Hashtag generator", "Find tags that match your movie genre", "Hashtags"),
            Triple("Movie script helper", "Create a short narration outline", "Scripts"),
            Triple("View & follower log", "Record your public analytics manually", "Tracker"),
            Triple("Creator tips", "Improve hooks, pacing and consistency", "Tips")
        ).forEach { (title, desc, dest) ->
            CardRow(title, desc) { go(dest) }
        }
        Text("Note: TikTok views and followers cannot be increased or read automatically by this starter app. Use TikTok's own analytics and enter figures in Tracker.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun StatCard(kicker: String, value: String, detail: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(kicker, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun CardRow(title: String, desc: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = White, fontWeight = FontWeight.Bold)
            Text(desc, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun HashtagPage(genre: String, setGenre: (String) -> Unit, copy: (String) -> Unit) {
    val tags = when (genre) {
        "Horror" -> "#CINESPHERE #HorrorMovie #ScaryMovie #ThrillerMovie #MovieRecap #MyanmarTikTok"
        "Romance" -> "#CINESPHERE #RomanceMovie #LoveStory #MovieReview #MovieRecap #MyanmarTikTok"
        "Comedy" -> "#CINESPHERE #ComedyMovie #FunnyMovies #MovieReview #MovieRecap #MyanmarTikTok"
        "War" -> "#CINESPHERE #WarMovie #ActionMovie #MovieStory #MovieRecap #MyanmarTikTok"
        else -> "#CINESPHERE #ActionMovie #MovieRecap #MovieReview #FilmTok #MyanmarTikTok"
    }
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        PageTitle("Hashtag generator", "Choose the closest genre; use only relevant tags")
        GenrePicker(genre, setGenre)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel)) {
            Text(tags, color = Cyan, fontSize = 15.sp, modifier = Modifier.padding(16.dp))
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { copy(tags) }, modifier = Modifier.fillMaxWidth()) { Text("Copy hashtags") }
        Text("Tip: Try 4–6 relevant hashtags rather than pasting the same large set on every post.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun GenrePicker(genre: String, setGenre: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("Action", "War", "Horror", "Romance", "Comedy").forEach {
            FilterChip(selected = genre == it, onClick = { setGenre(it) }, label = { Text(it, fontSize = 10.sp) })
        }
    }
    Spacer(Modifier.height(14.dp))
}

@Composable
fun ScriptPage(movie: String, setMovie: (String) -> Unit, caption: String, setCaption: (String) -> Unit, copy: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        PageTitle("Movie content helper", "Create a reusable narration and caption starter")
        InputField("Movie title", movie, setMovie)
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            val name = movie.ifBlank { "ဒီဇာတ်ကား" }
            setCaption("ဒီဇာတ်ကားမှာတော့ $name ရဲ့ စိတ်ဝင်စားစရာဇာတ်လမ်းကို တင်ဆက်ပေးထားပါတယ်။ ဇာတ်လမ်းအပြည့်အစုံကို သိချင်ရင် အဆုံးထိကြည့်ရှုပေးပါ။ သင်ကြိုက်တဲ့အပိုင်းကို comment မှာ ပြောပြခဲ့ပါ။")
        }, modifier = Modifier.fillMaxWidth()) { Text("Generate Burmese caption") }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Text(if (caption.isBlank()) "Generated caption will appear here." else caption,
                color = White, modifier = Modifier.padding(15.dp))
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { copy(caption) }, enabled = caption.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Copy caption") }
        Text("This is a starter caption, not a full movie script. Add your own accurate plot details and avoid uploading copyrighted full scenes.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun InputField(label: String, value: String, onValue: (String) -> Unit) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(5.dp))
        OutlinedTextField(value, onValue, modifier = Modifier.fillMaxWidth(), singleLine = true)
    }
}

@Composable
fun TrackerPage(views: String, setViews: (String) -> Unit, followers: String, setFollowers: (String) -> Unit,
                savedViews: Int, savedFollowers: Int, save: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        PageTitle("Growth tracker", "Enter numbers from TikTok analytics")
        StatCard("LAST SAVED VIEW COUNT", savedViews.toString(), "Manual record")
        Spacer(Modifier.height(8.dp))
        StatCard("LAST SAVED FOLLOWERS", savedFollowers.toString(), "Manual record")
        Spacer(Modifier.height(14.dp))
        InputField("Current video views", views, setViews)
        Spacer(Modifier.height(8.dp))
        InputField("Current follower count", followers, setFollowers)
        Spacer(Modifier.height(12.dp))
        Button(onClick = save, modifier = Modifier.fillMaxWidth()) { Text("Save this snapshot") }
        Text("Starter version stores values only while the app is open. Persistent history and official TikTok API connection can be added after setup and permissions.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun TipsPage() {
    val tips = listOf(
        "Start with a strong 1–2 second hook that creates curiosity.",
        "Keep the narration clear and add readable Burmese subtitles.",
        "Use a relevant caption and a small set of topic-specific hashtags.",
        "Review watch time, completion rate and follows in TikTok analytics.",
        "Test different posting times; compare results instead of guessing.",
        "Use footage, music and posters only when you have permission or the right to use them."
    )
    Column(Modifier.fillMaxWidth().padding(18.dp)) {
        PageTitle("Creator growth tips", "Improve content quality and audience retention")
        tips.forEachIndexed { index, tip ->
            Card(Modifier.fillMaxWidth().padding(bottom = 9.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Text("${index + 1}.", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(10.dp))
                    Text(tip, color = White, fontSize = 13.sp)
                }
            }
        }
    }
}
